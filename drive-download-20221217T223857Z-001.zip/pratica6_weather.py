from requests import get
import json
from pprint import pprint
from picamera import PiCamera, Color
from time import sleep

stations = 'https://apex.oracle.com/pls/apex/raspberrypi/weatherstation/getallstations'
weather = 'https://apex.oracle.com/pls/apex/raspberrypi/weatherstation/getlatestmeasurements/966583'

my_weather = get(weather).json()['items']
pprint(my_weather)

camera = PiCamera()

camera.rotation = 180

camera.annotate_text_size = 30
camera.annotate_background = Color('blue')
camera.annotate_text = "Luis Otavio: 11234721; Lucas Pires: 11819452"

camera.start_preview()

sleep(3)
camera.capture('/home/sel/sel0337_LuisO_Lucas/image.jpg')

camera.start_recording('/home/sel/sel0337_LuisO_Lucas/video.h264')
sleep(5)
camera.stop_recording()

camera.stop_preview()
